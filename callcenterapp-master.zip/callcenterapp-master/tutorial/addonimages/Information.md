## The purpose of this folder is to provide a quick reference to images used in the add-on part of the tutorial. 
