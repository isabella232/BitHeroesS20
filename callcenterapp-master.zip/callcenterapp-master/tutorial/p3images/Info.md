# **For convenience, this folder contains images used in part 1 of the tutorial (blogp3.md).**
